/*
 * Copyright 2010 UnboundID Corp.
 * All Rights Reserved.
 */
/*
 * Copyright (C) 2010 UnboundID Corp.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (GPLv2 only)
 * or the terms of the GNU Lesser General Public License (LGPLv2.1 only)
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses>.
 */
package com.unboundid.util;



import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;



/**
 * This enum defines a set of message keys for messages in the
 * com.unboundid.util package, which correspond to messages in the
 * util.properties properties file.
 * <BR><BR>
 * This source file was generated from the properties file.
 * Do not edit it directly.
 */
enum UtilityMessages
{
  /**
   * A base64-encoded string must have a length that is a multiple of 4 bytes.
   */
  ERR_BASE64_DECODE_INVALID_LENGTH("A base64-encoded string must have a length that is a multiple of 4 bytes."),



  /**
   * Invalid character ''{0}'' encountered.
   */
  ERR_BASE64_DECODE_UNEXPECTED_CHAR("Invalid character ''{0}'' encountered."),



  /**
   * Unexpected equal sign found at position {0,number,0}.
   */
  ERR_BASE64_DECODE_UNEXPECTED_EQUAL("Unexpected equal sign found at position {0,number,0}."),



  /**
   * The provided array is null.
   */
  ERR_BS_BUFFER_ARRAY_NULL("The provided array is null."),



  /**
   * The provided buffer is null.
   */
  ERR_BS_BUFFER_BUFFER_NULL("The provided buffer is null."),



  /**
   * The provided byte string is null.
   */
  ERR_BS_BUFFER_BYTE_STRING_NULL("The provided byte string is null."),



  /**
   * The provided capacity {0,number,0} is negative.
   */
  ERR_BS_BUFFER_CAPACITY_NEGATIVE("The provided capacity {0,number,0} is negative."),



  /**
   * The provided character sequence is null.
   */
  ERR_BS_BUFFER_CHAR_SEQUENCE_NULL("The provided character sequence is null."),



  /**
   * The provided length {0,number,0} is negative.
   */
  ERR_BS_BUFFER_LENGTH_NEGATIVE("The provided length {0,number,0} is negative."),



  /**
   * The provided offset {0,number,0} is negative.
   */
  ERR_BS_BUFFER_OFFSET_NEGATIVE("The provided offset {0,number,0} is negative."),



  /**
   * The provided offset {0,number,0} plus the provided length {1,number,0} is greater than the size of the provided array ({2,number,0}).
   */
  ERR_BS_BUFFER_OFFSET_PLUS_LENGTH_TOO_LARGE("The provided offset {0,number,0} plus the provided length {1,number,0} is greater than the size of the provided array ({2,number,0})."),



  /**
   * The provided position {0,number,0} is negative.
   */
  ERR_BS_BUFFER_POS_NEGATIVE("The provided position {0,number,0} is negative."),



  /**
   * The provided position {0,number,0} is greater than the length of the buffer ({1,number,0}).
   */
  ERR_BS_BUFFER_POS_TOO_LARGE("The provided position {0,number,0} is greater than the length of the buffer ({1,number,0})."),



  /**
   * Unable to decode bytes ''{0}'' as a valid UUID because the length of the provided content was not exactly 128 bits.
   */
  ERR_DECODE_UUID_INVALID_LENGTH("Unable to decode bytes ''{0}'' as a valid UUID because the length of the provided content was not exactly 128 bits."),



  /**
   * Unable to access data in file ''{0}'' for use in the value pattern:  {1}
   */
  ERR_FILE_VALUE_PATTERN_NOT_USABLE("Unable to access data in file ''{0}'' for use in the value pattern:  {1}"),



  /**
   * Attempted to write beyond the end of the array backing the output stream
   */
  ERR_FIXED_ARRAY_OS_WRITE_BEYOND_END("Attempted to write beyond the end of the array backing the output stream"),



  /**
   * Unable to parse the provided timestamp ''{0}'' because it had an invalid number of characters before the sub-second and/or time zone portion.
   */
  ERR_GENTIME_CANNOT_PARSE_INVALID_LENGTH("Unable to parse the provided timestamp ''{0}'' because it had an invalid number of characters before the sub-second and/or time zone portion."),



  /**
   * Unable to parse time zone information from the provided timestamp ''{0}''.
   */
  ERR_GENTIME_DECODE_CANNOT_PARSE_TZ("Unable to parse time zone information from the provided timestamp ''{0}''."),



  /**
   * Unable to access data from ''{0}'' for use in the value pattern:  {1}
   */
  ERR_HTTP_VALUE_PATTERN_NOT_USABLE("Unable to access data from ''{0}'' for use in the value pattern:  {1}"),



  /**
   * Unable to create the key manager for secure communication:  {0}
   */
  ERR_LDAP_TOOL_CANNOT_CREATE_KEY_MANAGER("Unable to create the key manager for secure communication:  {0}"),



  /**
   * Unable to create the SSL context to for StartTLS communication with the server:  {0}
   */
  ERR_LDAP_TOOL_CANNOT_CREATE_SSL_CONTEXT("Unable to create the SSL context to for StartTLS communication with the server:  {0}"),



  /**
   * Unable to create the SSL socket factory to use for secure communication with the server:  {0}
   */
  ERR_LDAP_TOOL_CANNOT_CREATE_SSL_SOCKET_FACTORY("Unable to create the SSL socket factory to use for secure communication with the server:  {0}"),



  /**
   * Unable to read the bind password:  {0}
   */
  ERR_LDAP_TOOL_CANNOT_READ_BIND_PASSWORD("Unable to read the bind password:  {0}"),



  /**
   * Unable to read the key store password:  {0}
   */
  ERR_LDAP_TOOL_CANNOT_READ_KEY_STORE_PASSWORD("Unable to read the key store password:  {0}"),



  /**
   * Unable to read the trust store password:  {0}
   */
  ERR_LDAP_TOOL_CANNOT_READ_TRUST_STORE_PASSWORD("Unable to read the trust store password:  {0}"),



  /**
   * If either the ''--{0}'' or ''--{1}'' arguments are provided multiple times, then both arguments must be provided the same number of times.
   */
  ERR_LDAP_TOOL_HOST_PORT_COUNT_MISMATCH("If either the ''--{0}'' or ''--{1}'' arguments are provided multiple times, then both arguments must be provided the same number of times."),



  /**
   * SASL option ''{0}'' cannot be used with the {1} mechanism.
   */
  ERR_LDAP_TOOL_INVALID_SASL_OPTION("SASL option ''{0}'' cannot be used with the {1} mechanism."),



  /**
   * SASL option ''{0}'' is invalid.  SASL options must be in the form ''name=value''.
   */
  ERR_LDAP_TOOL_MALFORMED_SASL_OPTION("SASL option ''{0}'' is invalid.  SASL options must be in the form ''name=value''."),



  /**
   * SASL option ''{0}'' is required for use with the {1} mechanism.
   */
  ERR_LDAP_TOOL_MISSING_REQUIRED_SASL_OPTION("SASL option ''{0}'' is required for use with the {1} mechanism."),



  /**
   * One or more SASL options were provided, but the ''mech'' option was not given to indicate which SASL mechanism to use.
   */
  ERR_LDAP_TOOL_NO_SASL_MECH("One or more SASL options were provided, but the ''mech'' option was not given to indicate which SASL mechanism to use."),



  /**
   * StartTLS negotiation failed:  {0}
   */
  ERR_LDAP_TOOL_START_TLS_FAILED("StartTLS negotiation failed:  {0}"),



  /**
   * SASL mechanism ''{0}'' is not supported.
   */
  ERR_LDAP_TOOL_UNSUPPORTED_SASL_MECH("SASL mechanism ''{0}'' is not supported."),



  /**
   * No Exception
   */
  ERR_NO_EXCEPTION("No Exception"),



  /**
   * {0}.  Thread stack trace:  {1}
   */
  ERR_VALIDATOR_FAILURE_CUSTOM_MESSAGE("{0}.  Thread stack trace:  {1}"),



  /**
   * A result of true was found for a condition which the LDAP SDK requires to be false.  Thread stack trace {0}
   */
  ERR_VALIDATOR_FALSE_CHECK_FAILURE("A result of true was found for a condition which the LDAP SDK requires to be false.  Thread stack trace {0}"),



  /**
   * A null object was provided where a non-null object is required (non-null index {0,number,0}).  Thread stack trace:  {1}
   */
  ERR_VALIDATOR_NULL_CHECK_FAILURE("A null object was provided where a non-null object is required (non-null index {0,number,0}).  Thread stack trace:  {1}"),



  /**
   * A result of false was found for a condition which the LDAP SDK requires to be true.  Thread stack trace {0}
   */
  ERR_VALIDATOR_TRUE_CHECK_FAILURE("A result of false was found for a condition which the LDAP SDK requires to be true.  Thread stack trace {0}"),



  /**
   * The specified file does not contain any data.
   */
  ERR_VALUE_PATTERN_COMPONENT_EMPTY_FILE("The specified file does not contain any data."),



  /**
   * The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length format string.
   */
  ERR_VALUE_PATTERN_EMPTY_FORMAT("The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length format string."),



  /**
   * The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length increment.
   */
  ERR_VALUE_PATTERN_EMPTY_INCREMENT("The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length increment."),



  /**
   * The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length lower bound.
   */
  ERR_VALUE_PATTERN_EMPTY_LOWER_BOUND("The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length lower bound."),



  /**
   * The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length upper bound.
   */
  ERR_VALUE_PATTERN_EMPTY_UPPER_BOUND("The provided value pattern string contained a numeric range starting at position {0,number,0} which contained a zero-length upper bound."),



  /**
   * The provided value pattern string contained an invalid character ''{0}'' at position {1,number,0}.
   */
  ERR_VALUE_PATTERN_INVALID_CHARACTER("The provided value pattern string contained an invalid character ''{0}'' at position {1,number,0}."),



  /**
   * The provided value pattern string contained a numeric range starting at position {0,number,0} which did not contain either a dash or colon to separate the lower bound from the upper bound.
   */
  ERR_VALUE_PATTERN_NO_DELIMITER("The provided value pattern string contained a numeric range starting at position {0,number,0} which did not contain either a dash or colon to separate the lower bound from the upper bound."),



  /**
   * The provided value pattern string contained an unmatched closing brace at position {0,number,0}.
   */
  ERR_VALUE_PATTERN_UNMATCHED_CLOSE("The provided value pattern string contained an unmatched closing brace at position {0,number,0}."),



  /**
   * The provided value pattern string contained an unmatched opening brace at position {0,number,0}.
   */
  ERR_VALUE_PATTERN_UNMATCHED_OPEN("The provided value pattern string contained an unmatched opening brace at position {0,number,0}."),



  /**
   * The provided value pattern string contained a numeric range starting at position {0,number,0} with a value that is outside the acceptable range.  Values must be between {1,number,0} and {2,number,0}.
   */
  ERR_VALUE_PATTERN_VALUE_NOT_LONG("The provided value pattern string contained a numeric range starting at position {0,number,0} with a value that is outside the acceptable range.  Values must be between {1,number,0} and {2,number,0}."),



  /**
   * Display usage information for this program.
   */
  INFO_CL_TOOL_DESCRIPTION_HELP("Display usage information for this program."),



  /**
   * Examples
   */
  INFO_CL_TOOL_LABEL_EXAMPLES("Examples"),



  /**
   * Timestamp
   */
  INFO_COLUMN_LABEL_TIMESTAMP("Timestamp"),



  /**
   * The DN to use to bind to the directory server when performing simple authentication.
   */
  INFO_LDAP_TOOL_DESCRIPTION_BIND_DN("The DN to use to bind to the directory server when performing simple authentication."),



  /**
   * The password to use to bind to the directory server when performing simple authentication or a password-based SASL mechanism.
   */
  INFO_LDAP_TOOL_DESCRIPTION_BIND_PW("The password to use to bind to the directory server when performing simple authentication or a password-based SASL mechanism."),



  /**
   * The path to the file containing the password to use to bind to the directory server when performing simple authentication or a password-based SASL mechanism.
   */
  INFO_LDAP_TOOL_DESCRIPTION_BIND_PW_FILE("The path to the file containing the password to use to bind to the directory server when performing simple authentication or a password-based SASL mechanism."),



  /**
   * The nickname (alias) of the client certificate in the key store to present to the directory server for SSL client authentication.
   */
  INFO_LDAP_TOOL_DESCRIPTION_CERT_NICKNAME("The nickname (alias) of the client certificate in the key store to present to the directory server for SSL client authentication."),



  /**
   * The IP address or resolvable name to use to connect to the directory server.  If this is not provided, then a default value of 'localhost' will be used.
   */
  INFO_LDAP_TOOL_DESCRIPTION_HOST("The IP address or resolvable name to use to connect to the directory server.  If this is not provided, then a default value of 'localhost' will be used."),



  /**
   * The password to use to access the key store contents.
   */
  INFO_LDAP_TOOL_DESCRIPTION_KEY_STORE_PASSWORD("The password to use to access the key store contents."),



  /**
   * The path to the file containing the password to use to access the key store contents.
   */
  INFO_LDAP_TOOL_DESCRIPTION_KEY_STORE_PASSWORD_FILE("The path to the file containing the password to use to access the key store contents."),



  /**
   * The path to the file to use as the key store for obtaining client certificates when communicating securely with the directory server.
   */
  INFO_LDAP_TOOL_DESCRIPTION_KEY_STORE_PATH("The path to the file to use as the key store for obtaining client certificates when communicating securely with the directory server."),



  /**
   * The port to use to connect to the directory server.  If this is not provided, then a default value of 389 will be used.
   */
  INFO_LDAP_TOOL_DESCRIPTION_PORT("The port to use to connect to the directory server.  If this is not provided, then a default value of 389 will be used."),



  /**
   * A name-value pair providing information to use when performing SASL authentication.
   */
  INFO_LDAP_TOOL_DESCRIPTION_SASL_OPTION("A name-value pair providing information to use when performing SASL authentication."),



  /**
   * Trust any certificate presented by the directory server.
   */
  INFO_LDAP_TOOL_DESCRIPTION_TRUST_ALL("Trust any certificate presented by the directory server."),



  /**
   * The password to use to access the trust store contents.
   */
  INFO_LDAP_TOOL_DESCRIPTION_TRUST_STORE_PASSWORD("The password to use to access the trust store contents."),



  /**
   * The path to the file containing the password to use to access the trust store contents.
   */
  INFO_LDAP_TOOL_DESCRIPTION_TRUST_STORE_PASSWORD_FILE("The path to the file containing the password to use to access the trust store contents."),



  /**
   * The path to the file to use as trust store when determining whether to trust a certificate presented by the directory server.
   */
  INFO_LDAP_TOOL_DESCRIPTION_TRUST_STORE_PATH("The path to the file to use as trust store when determining whether to trust a certificate presented by the directory server."),



  /**
   * Use SSL when communicating with the directory server.
   */
  INFO_LDAP_TOOL_DESCRIPTION_USE_SSL("Use SSL when communicating with the directory server."),



  /**
   * Use StartTLS when communicating with the directory server.
   */
  INFO_LDAP_TOOL_DESCRIPTION_USE_START_TLS("Use StartTLS when communicating with the directory server."),



  /**
   * {nickname}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_CERT_NICKNAME("{nickname}"),



  /**
   * {dn}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_DN("{dn}"),



  /**
   * {host}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_HOST("{host}"),



  /**
   * {password}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_PASSWORD("{password}"),



  /**
   * {path}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_PATH("{path}"),



  /**
   * {port}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_PORT("{port}"),



  /**
   * {name=value}
   */
  INFO_LDAP_TOOL_PLACEHOLDER_SASL_OPTION("{name=value}"),



  /**
   * {0,number,0} days
   */
  INFO_NUM_DAYS_PLURAL("{0,number,0} days"),



  /**
   * {0,number,0} day
   */
  INFO_NUM_DAYS_SINGULAR("{0,number,0} day"),



  /**
   * {0,number,0} hours
   */
  INFO_NUM_HOURS_PLURAL("{0,number,0} hours"),



  /**
   * {0,number,0} hour
   */
  INFO_NUM_HOURS_SINGULAR("{0,number,0} hour"),



  /**
   * {0,number,0} minutes
   */
  INFO_NUM_MINUTES_PLURAL("{0,number,0} minutes"),



  /**
   * {0,number,0} minute
   */
  INFO_NUM_MINUTES_SINGULAR("{0,number,0} minute"),



  /**
   * {0,number,0} seconds
   */
  INFO_NUM_SECONDS_PLURAL("{0,number,0} seconds"),



  /**
   * {0,number,0} second
   */
  INFO_NUM_SECONDS_SINGULAR("{0,number,0} second"),



  /**
   * {0} seconds
   */
  INFO_NUM_SECONDS_WITH_DECIMAL("{0} seconds");



  /**
   * The resource bundle that will be used to load the properties file.
   */
  private static final ResourceBundle RESOURCE_BUNDLE;
  static
  {
    ResourceBundle rb = null;
    try
    {
      rb = ResourceBundle.getBundle("util");
    } catch (Exception e) {}
    RESOURCE_BUNDLE = rb;
  }



  /**
   * The map that will be used to hold the unformatted message strings, indexed by property name.
   */
  private static final ConcurrentHashMap<UtilityMessages,String> MESSAGE_STRINGS = new ConcurrentHashMap<UtilityMessages,String>();



  /**
   * The map that will be used to hold the message format objects, indexed by property name.
   */
  private static final ConcurrentHashMap<UtilityMessages,MessageFormat> MESSAGES = new ConcurrentHashMap<UtilityMessages,MessageFormat>();



  // The default text for this message
  private final String defaultText;



  /**
   * Creates a new message key.
   */
  private UtilityMessages(final String defaultText)
  {
    this.defaultText = defaultText;
  }



  /**
   * Retrieves a localized version of the message.
   * This method should only be used for messages which do not take any arguments.
   *
   * @return  A localized version of the message.
   */
  public String get()
  {
    String s = MESSAGE_STRINGS.get(this);
    if (s == null)
    {
      if (RESOURCE_BUNDLE == null)
      {
        return defaultText;
      }
      else
      {
        s = RESOURCE_BUNDLE.getString(name());
        MESSAGE_STRINGS.putIfAbsent(this, s);
      }
    }
    return s;
  }



  /**
   * Retrieves a localized version of the message.
   *
   * @param  args  The arguments to use to format the message.
   *
   * @return  A localized version of the message.
   */
  public String get(final Object... args)
  {
    MessageFormat f = MESSAGES.get(this);
    if (f == null)
    {
      if (RESOURCE_BUNDLE == null)
      {
        f = new MessageFormat(defaultText);
      }
      else
      {
        f = new MessageFormat(RESOURCE_BUNDLE.getString(name()));
      }
      MESSAGES.putIfAbsent(this, f);
    }
    synchronized (f)
    {
      return f.format(args);
    }
  }



  /**
   * Retrieves a string representation of this message key.
   *
   * @return  A string representation of this message key.
   */
  @Override()
  public String toString()
  {
    return get();
  }
}

