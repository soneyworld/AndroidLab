/*
 * Copyright 2010 UnboundID Corp.
 * All Rights Reserved.
 */
/*
 * Copyright (C) 2010 UnboundID Corp.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License (GPLv2 only)
 * or the terms of the GNU Lesser General Public License (LGPLv2.1 only)
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses>.
 */
package com.unboundid.util.args;



import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;



/**
 * This enum defines a set of message keys for messages in the
 * com.unboundid.util.args package, which correspond to messages in the
 * args.properties properties file.
 * <BR><BR>
 * This source file was generated from the properties file.
 * Do not edit it directly.
 */
enum ArgsMessages
{
  /**
   * Argument ''{0}'' is already registered with an argument parser and cannot be registered a second time or with a different parser.
   */
  ERR_ARG_ALREADY_REGISTERED("Argument ''{0}'' is already registered with an argument parser and cannot be registered a second time or with a different parser."),



  /**
   * The provided description was null.
   */
  ERR_ARG_DESCRIPTION_NULL("The provided description was null."),



  /**
   * The set of identifiers for argument ''{0}'' cannot be altered because the argument has already been registered with an argument parser.
   */
  ERR_ARG_ID_CHANGE_AFTER_REGISTERED("The set of identifiers for argument ''{0}'' cannot be altered because the argument has already been registered with an argument parser."),



  /**
   * The ''{0}'' argument was provided more than the maximum allowed number of times for that argument.
   */
  ERR_ARG_MAX_OCCURRENCES_EXCEEDED("The ''{0}'' argument was provided more than the maximum allowed number of times for that argument."),



  /**
   * A value placeholder must be provided for the ''{0}'' argument.
   */
  ERR_ARG_MUST_TAKE_VALUE("A value placeholder must be provided for the ''{0}'' argument."),



  /**
   * At least one of the short and long identifiers must be non-null.
   */
  ERR_ARG_NO_IDENTIFIERS("At least one of the short and long identifiers must be non-null."),



  /**
   * The provided value ''{0}'' is not allowed for argument ''{1}''.
   */
  ERR_ARG_VALUE_NOT_ALLOWED("The provided value ''{0}'' is not allowed for argument ''{1}''."),



  /**
   * The ''{0}'' argument does not take a value.
   */
  ERR_BOOLEAN_VALUES_NOT_ALLOWED("The ''{0}'' argument does not take a value."),



  /**
   * The provided value ''{0}'' for argument ''{1}'' could not be parsed as a distinguished name:  {2}
   */
  ERR_DN_VALUE_NOT_DN("The provided value ''{0}'' for argument ''{1}'' could not be parsed as a distinguished name:  {2}"),



  /**
   * File argument ''{0}'' is configured to require values to be both files and directories.  This is not allowed.
   */
  ERR_FILE_CANNOT_BE_FILE_AND_DIRECTORY("File argument ''{0}'' is configured to require values to be both files and directories.  This is not allowed."),



  /**
   * Unable to fully read the contents of file ''{0}'' specified as the value for argument ''{1}''.
   */
  ERR_FILE_CANNOT_READ_FULLY("Unable to fully read the contents of file ''{0}'' specified as the value for argument ''{1}''."),



  /**
   * The file ''{0}'' specified as the value for argument ''{1}'' does not exist.
   */
  ERR_FILE_DOESNT_EXIST("The file ''{0}'' specified as the value for argument ''{1}'' does not exist."),



  /**
   * The file ''{0}'' specified as the value for argument ''{1}'' does not exist, and its parent also does not exist or is not a directory.
   */
  ERR_FILE_PARENT_DOESNT_EXIST("The file ''{0}'' specified as the value for argument ''{1}'' does not exist, and its parent also does not exist or is not a directory."),



  /**
   * The value for file argument ''{0}'' resolves to path ''{1}'' which exists but is not a directory.
   */
  ERR_FILE_VALUE_NOT_DIRECTORY("The value for file argument ''{0}'' resolves to path ''{1}'' which exists but is not a directory."),



  /**
   * The value for file argument ''{0}'' resolves to path ''{1}'' which exists but is not a file.
   */
  ERR_FILE_VALUE_NOT_FILE("The value for file argument ''{0}'' resolves to path ''{1}'' which exists but is not a file."),



  /**
   * The provided value ''{0}'' for argument ''{1}'' could not be parsed as a search filter:  {2}
   */
  ERR_FILTER_VALUE_NOT_FILTER("The provided value ''{0}'' for argument ''{1}'' could not be parsed as a search filter:  {2}"),



  /**
   * The provided value {0,number,0} for argument ''{1}'' was larger than the upper bound of {2,number,0}.
   */
  ERR_INTEGER_VALUE_ABOVE_UPPER_BOUND("The provided value {0,number,0} for argument ''{1}'' was larger than the upper bound of {2,number,0}."),



  /**
   * The provided value {0,number,0} for argument ''{1}'' was smaller than the lower bound of {2,number,0}.
   */
  ERR_INTEGER_VALUE_BELOW_LOWER_BOUND("The provided value {0,number,0} for argument ''{1}'' was smaller than the lower bound of {2,number,0}."),



  /**
   * The provided value ''{0}'' for argument ''{1}'' could not be parsed as an integer.
   */
  ERR_INTEGER_VALUE_NOT_INT("The provided value ''{0}'' for argument ''{1}'' could not be parsed as an integer."),



  /**
   * The provided command description was null.
   */
  ERR_PARSER_COMMAND_DESCRIPTION_NULL("The provided command description was null."),



  /**
   * The provided command name was null.
   */
  ERR_PARSER_COMMAND_NAME_NULL("The provided command name was null."),



  /**
   * If argument ''{0}'' is provided, then at least one of the following arguments must also be given:  {1}.
   */
  ERR_PARSER_DEPENDENT_CONFLICT_MULTIPLE("If argument ''{0}'' is provided, then at least one of the following arguments must also be given:  {1}."),



  /**
   * If argument ''{0}'' is provided, then argument ''{1}'' must also be given.
   */
  ERR_PARSER_DEPENDENT_CONFLICT_SINGLE("If argument ''{0}'' is provided, then argument ''{1}'' must also be given."),



  /**
   * Arguments ''{0}'' and ''{1}'' are not allowed to be used together.
   */
  ERR_PARSER_EXCLUSIVE_CONFLICT("Arguments ''{0}'' and ''{1}'' are not allowed to be used together."),



  /**
   * Argument ''--{0}'' does not take a value.
   */
  ERR_PARSER_LONG_ARG_DOESNT_TAKE_VALUE("Argument ''--{0}'' does not take a value."),



  /**
   * Argument ''--{0}'' requires a value.
   */
  ERR_PARSER_LONG_ARG_MISSING_VALUE("Argument ''--{0}'' requires a value."),



  /**
   * Another argument is already registered with a long identifier of ''{0}''.
   */
  ERR_PARSER_LONG_ID_CONFLICT("Another argument is already registered with a long identifier of ''{0}''."),



  /**
   * Argument ''{0}'' is required to be present but was not provided and does not have a default value.
   */
  ERR_PARSER_MISSING_REQUIRED_ARG("Argument ''{0}'' is required to be present but was not provided and does not have a default value."),



  /**
   * Unknown argument ''-{0}'' referenced in string ''{1}''.
   */
  ERR_PARSER_NO_SUBSEQUENT_SHORT_ARG("Unknown argument ''-{0}'' referenced in string ''{1}''."),



  /**
   * Unknown argument ''--{0}''
   */
  ERR_PARSER_NO_SUCH_LONG_ID("Unknown argument ''--{0}''"),



  /**
   * Unknown argument ''-{0}''
   */
  ERR_PARSER_NO_SUCH_SHORT_ID("Unknown argument ''-{0}''"),



  /**
   * At least one of the following arguments is required to be present:  {0}.
   */
  ERR_PARSER_REQUIRED_CONFLICT("At least one of the following arguments is required to be present:  {0}."),



  /**
   * Argument ''-{0}'' requires a value.
   */
  ERR_PARSER_SHORT_ARG_MISSING_VALUE("Argument ''-{0}'' requires a value."),



  /**
   * Another argument is already registered with a short identifier of ''{0}''.
   */
  ERR_PARSER_SHORT_ID_CONFLICT("Another argument is already registered with a short identifier of ''{0}''."),



  /**
   * Argument ''-{0}'' referenced in string ''{1}'' requires a value, but arguments which take values cannot be referenced by their short identifier in a single string containing other arguments referenced by their short identifiers.
   */
  ERR_PARSER_SUBSEQUENT_SHORT_ARG_TAKES_VALUE("Argument ''-{0}'' referenced in string ''{1}'' requires a value, but arguments which take values cannot be referenced by their short identifier in a single string containing other arguments referenced by their short identifiers."),



  /**
   * Argument ''{0}'' is not acceptable because command ''{1}'' does not allow more than {2} unnamed trailing argument(s).
   */
  ERR_PARSER_TOO_MANY_TRAILING_ARGS("Argument ''{0}'' is not acceptable because command ''{1}'' does not allow more than {2} unnamed trailing argument(s)."),



  /**
   * Argument ''{0}'' is not acceptable because command ''{1}'' does not allow unnamed trailing arguments.
   */
  ERR_PARSER_TRAILING_ARGS_NOT_ALLOWED("Argument ''{0}'' is not acceptable because command ''{1}'' does not allow unnamed trailing arguments."),



  /**
   * The argument parser was configured to allow unnamed trailing arguments, but the trailing args placeholder was null.
   */
  ERR_PARSER_TRAILING_ARGS_PLACEHOLDER_NULL("The argument parser was configured to allow unnamed trailing arguments, but the trailing args placeholder was null."),



  /**
   * Unexpected lone ''-'' character in argument list.
   */
  ERR_PARSER_UNEXPECTED_DASH("Unexpected lone ''-'' character in argument list."),



  /**
   * Usage:  {0}
   */
  INFO_USAGE_NOOPTIONS_NOTRAILING("Usage:  {0}"),



  /**
   * Usage:  {0} {1}
   */
  INFO_USAGE_NOOPTIONS_TRAILING("Usage:  {0} {1}"),



  /**
   * Available options include:
   */
  INFO_USAGE_OPTIONS_INCLUDE("Available options include:"),



  /**
   * Usage:  {0} '{'options'}'
   */
  INFO_USAGE_OPTIONS_NOTRAILING("Usage:  {0} '{'options'}'"),



  /**
   * Usage:  {0} '{'options'}' {1}
   */
  INFO_USAGE_OPTIONS_TRAILING("Usage:  {0} '{'options'}' {1}");



  /**
   * The resource bundle that will be used to load the properties file.
   */
  private static final ResourceBundle RESOURCE_BUNDLE;
  static
  {
    ResourceBundle rb = null;
    try
    {
      rb = ResourceBundle.getBundle("args");
    } catch (Exception e) {}
    RESOURCE_BUNDLE = rb;
  }



  /**
   * The map that will be used to hold the unformatted message strings, indexed by property name.
   */
  private static final ConcurrentHashMap<ArgsMessages,String> MESSAGE_STRINGS = new ConcurrentHashMap<ArgsMessages,String>();



  /**
   * The map that will be used to hold the message format objects, indexed by property name.
   */
  private static final ConcurrentHashMap<ArgsMessages,MessageFormat> MESSAGES = new ConcurrentHashMap<ArgsMessages,MessageFormat>();



  // The default text for this message
  private final String defaultText;



  /**
   * Creates a new message key.
   */
  private ArgsMessages(final String defaultText)
  {
    this.defaultText = defaultText;
  }



  /**
   * Retrieves a localized version of the message.
   * This method should only be used for messages which do not take any arguments.
   *
   * @return  A localized version of the message.
   */
  public String get()
  {
    String s = MESSAGE_STRINGS.get(this);
    if (s == null)
    {
      if (RESOURCE_BUNDLE == null)
      {
        return defaultText;
      }
      else
      {
        s = RESOURCE_BUNDLE.getString(name());
        MESSAGE_STRINGS.putIfAbsent(this, s);
      }
    }
    return s;
  }



  /**
   * Retrieves a localized version of the message.
   *
   * @param  args  The arguments to use to format the message.
   *
   * @return  A localized version of the message.
   */
  public String get(final Object... args)
  {
    MessageFormat f = MESSAGES.get(this);
    if (f == null)
    {
      if (RESOURCE_BUNDLE == null)
      {
        f = new MessageFormat(defaultText);
      }
      else
      {
        f = new MessageFormat(RESOURCE_BUNDLE.getString(name()));
      }
      MESSAGES.putIfAbsent(this, f);
    }
    synchronized (f)
    {
      return f.format(args);
    }
  }



  /**
   * Retrieves a string representation of this message key.
   *
   * @return  A string representation of this message key.
   */
  @Override()
  public String toString()
  {
    return get();
  }
}

